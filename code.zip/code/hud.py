# -*- coding: utf-8 -*-
"""
HUD 叠加绘制 + 颜色空间工具函数
"""
import cv2

from config import CFG


def bgr_to_rgb(img):
    return cv2.cvtColor(img, cv2.COLOR_BGR2RGB)


def rgb_to_bgr(img):
    return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)


def draw_hud_rgb(frame_rgb, red_result, yolo_result,
                 rc_tuple, pos_err, sm_active, af_raw, cand_info_text):
    """
    在 RGB 帧上绘制：
    - 门框检测框（红色 / YOLO）
    - RC 指令 & 误差 HUD 文字
    - 穿门状态 & 候选信息
    - 操作提示栏
    """
    h, w = frame_rgb.shape[:2]
    cx_img, cy_img = w // 2, h // 2
    cv2.circle(frame_rgb, (cx_img, cy_img), 6, (255, 255, 255), -1)

    if red_result and red_result.get("ok", False):
        x1, y1, x2, y2 = map(int, red_result["bbox"])
        cx, cy = red_result["center"]
        af = red_result["area_frac"]
        cv2.rectangle(frame_rgb, (x1, y1), (x2, y2), (0, 255, 0), 2)
        cv2.circle(frame_rgb, (cx, cy), 7, (0, 0, 255), -1)
        cv2.putText(frame_rgb, f"RED area={af:.3f}", (x1, max(0, y1 - 8)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)

    if yolo_result and yolo_result.get("ok", False):
        x1, y1, x2, y2 = map(int, yolo_result["bbox"])
        cx, cy = yolo_result["center"]
        af = yolo_result["area_frac"]
        cv2.rectangle(frame_rgb, (x1, y1), (x2, y2), (255, 0, 255), 2)
        cv2.circle(frame_rgb, (cx, cy), 7, (255, 0, 255), -1)
        cv2.putText(frame_rgb, f"YOLO area={af:.3f}", (x1, min(h - 5, y2 + 18)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

    r, p, t, y = rc_tuple
    ex, ey, ez = pos_err
    cv2.putText(frame_rgb,
                f"rc(r,p,t,y)=({r:+3d},{p:+3d},{t:+3d},{y:+3d})",
                (10, 28), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
    cv2.putText(frame_rgb,
                f"filt_err(ex,ey,af)=({ex:+.2f},{ey:+.2f},{ez:.3f})  raw_af={af_raw:.3f}",
                (10, 56), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
    cv2.putText(frame_rgb,
                f"SM_CROSS={'ON' if sm_active else 'off'}  NEAR_THR={CFG.NEAR_GATE_AREA_FRAC:.2f}",
                (10, 82), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)

    if cand_info_text:
        cv2.putText(frame_rgb, cand_info_text,
                    (10, 108), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

    cv2.putText(frame_rgb,
                "Keys: t takeoff | l land | m auto/manual | q/e yaw | w/s fwd/back "
                "| a/d left/right | r/f up/down | x stop | c cand | b backup | ESC quit",
                (10, h - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
