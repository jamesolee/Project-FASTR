# -*- coding: utf-8 -*-
"""
候选轨迹规划器（YOPO-style 锚点网格）：
- Mφ × Mθ 锚点均匀生成
- 代价评分：目标对齐 + 贴边惩罚 + 平滑 + BBox 奖励
- NMS 保留 Top1 / Top2
- 画面叠加可视化
"""
import cv2
import numpy as np

from config import CFG


class CandidatePlanner:
    """
    在图像上均匀生成 Mφ×Mθ 个锚点（anchors），综合代价：
    J = w_g*Jg + w_edge*Jedge + w_sm*Jsm + w_box*Jbox
    选出 #1/#2；#2 需与 #1 像素距离 >= NMS_PX。
    """

    def __init__(self, w: int, h: int):
        self.w, self.h = w, h
        self.grid_uv = self._make_grid(w, h, CFG.CAND_M_THETA, CFG.CAND_M_PHI)
        self.prev_sel_uv = None
        self.use_backup = False
        self.overlay_on = CFG.CAND_DRAW
        self.last_top = None
        self.last_top2 = None

    # ---------- 网格生成 ----------

    @staticmethod
    def _make_grid(w, h, m_theta, m_phi):
        us = [int((j + 0.5) / m_theta * w) for j in range(m_theta)]
        vs = [int((i + 0.5) / m_phi   * h) for i in range(m_phi)]
        return [(u, v) for v in vs for u in us]

    # ---------- 代价分量 ----------

    def _edge_penalty(self, u, v):
        margin_x = 0.12 * self.w
        margin_y = 0.12 * self.h
        dx = min(u, self.w - u)
        dy = min(v, self.h - v)
        px = max(0.0, (margin_x - dx) / margin_x)
        py = max(0.0, (margin_y - dy) / margin_y)
        return px * px + py * py

    def _smooth_penalty(self, u, v):
        if self.prev_sel_uv is None:
            return 0.0
        du = (u - self.prev_sel_uv[0]) / float(self.w)
        dv = (v - self.prev_sel_uv[1]) / float(self.h)
        return du * du + dv * dv

    def _goal_cost(self, u, v, gate_cx, gate_cy):
        ex = (u - gate_cx) / (0.5 * self.w)
        ey = (v - gate_cy) / (0.5 * self.h)
        return ex * ex + ey * ey

    def _bbox_bonus(self, u, v, bbox):
        if bbox is None:
            return 0.0
        x1, y1, x2, y2 = bbox
        shrink = 8
        if (x1 + shrink) < u < (x2 - shrink) and (y1 + shrink) < v < (y2 - shrink):
            return 1.0
        return 0.0

    # ---------- 评分 & 选优 ----------

    def _score_all(self, gate_center, bbox):
        if gate_center is None:
            return []
        gate_cx, gate_cy = gate_center
        scored = []
        for (u, v) in self.grid_uv:
            Jg = self._goal_cost(u, v, gate_cx, gate_cy)
            Je = self._edge_penalty(u, v)
            Js = self._smooth_penalty(u, v)
            Jb = self._bbox_bonus(u, v, bbox)
            J = (CFG.CAND_WG * Jg + CFG.CAND_WEDGE * Je
                 + CFG.CAND_WSM * Js + CFG.CAND_WBOX * Jb)
            scored.append((u, v, J))
        scored.sort(key=lambda x: x[2])
        return scored

    @staticmethod
    def _far_enough(p, q, thr):
        return abs(p[0] - q[0]) > thr or abs(p[1] - q[1]) > thr

    def select(self, gate_center, bbox):
        """
        返回 (top1, top2, ranked_list)；
        top1/top2 均为 (u, v, J) 或 None。
        """
        ranked = self._score_all(gate_center, bbox)
        if not ranked:
            self.last_top, self.last_top2 = None, None
            return None, None, []

        top1 = ranked[0]
        top2 = None
        for cand in ranked[1:]:
            if self._far_enough((top1[0], top1[1]), (cand[0], cand[1]), CFG.CAND_NMS_PX):
                top2 = cand
                break

        self.last_top, self.last_top2 = top1, top2
        return top1, top2, ranked[:CFG.CAND_MAX_DRAW]

    def commit_prev(self, uv):
        """记录本帧选中锚点，供下帧平滑代价使用。"""
        self.prev_sel_uv = uv

    # ---------- 开关 ----------

    def toggle_overlay(self):
        self.overlay_on = not self.overlay_on
        print(f"[CAND] overlay {'ON' if self.overlay_on else 'OFF'}")

    def toggle_backup(self):
        self.use_backup = not self.use_backup
        print(f"[CAND] use backup {'ON' if self.use_backup else 'OFF'}")

    # ---------- 可视化 ----------

    def draw(self, img_rgb, ranked, top1, top2):
        if not self.overlay_on or not ranked:
            return
        h, w = img_rgb.shape[:2]
        cx, cy = w // 2, h // 2

        Js = [r[2] for r in ranked]
        jmin, jmax = float(min(Js)), float(max(Js))
        jspan = max(1e-6, jmax - jmin)

        def color_for(J):
            t = (J - jmin) / jspan
            return (int(255 * t), int(255 * (1.0 - 0.5 * t)), 0)

        for (u, v, J) in ranked:
            cv2.line(img_rgb, (cx, cy), (int(u), int(v)), color_for(J), 1,
                     lineType=cv2.LINE_AA)

        if top1 is not None:
            u, v, J = top1
            cv2.line(img_rgb, (cx, cy), (int(u), int(v)), (0, 255, 0), 3,
                     lineType=cv2.LINE_AA)
            cv2.circle(img_rgb, (int(u), int(v)), 6, (0, 255, 0), -1)
            cv2.putText(img_rgb, "BEST#1", (int(u) + 6, int(v) - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)

        if top2 is not None:
            u, v, J = top2
            segs = 16
            for i in range(segs):
                if i % 2 == 0:
                    p0 = (int(cx + (u - cx) * i / segs),
                          int(cy + (v - cy) * i / segs))
                    p1 = (int(cx + (u - cx) * (i + 1) / segs),
                          int(cy + (v - cy) * (i + 1) / segs))
                    cv2.line(img_rgb, p0, p1, (0, 255, 255), 3, lineType=cv2.LINE_AA)
            cv2.circle(img_rgb, (int(u), int(v)), 6, (0, 255, 255), -1)
            cv2.putText(img_rgb, "ALT#2", (int(u) + 6, int(v) - 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
