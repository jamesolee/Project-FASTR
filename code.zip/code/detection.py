# -*- coding: utf-8 -*-
"""
门框检测模块：
- YOLO 检测（YOLOv11s）
- RED 颜色检测（HSV 红色掩膜）
"""
import cv2
import numpy as np
from ultralytics import YOLO

from config import CFG, DEVICE, HALF


# =========================
# YOLO helpers
# =========================

def load_model():
    """加载 YOLO 模型，返回 (model, gate_ids) 或 (None, None)"""
    import os
    if not os.path.exists(CFG.MODEL_PATH):
        print(f"[WARN] YOLO weights not found: {CFG.MODEL_PATH} — YOLO branch disabled.")
        return None, None

    print("[INFO] Loading YOLO model...")
    model = YOLO(CFG.MODEL_PATH)
    try:
        model.to(DEVICE)
        if HALF:
            try:
                model.model.half()
            except Exception:
                pass
        print(f"[INFO] Model on {DEVICE} | half={HALF}")
        if DEVICE.startswith("cuda"):
            import torch
            print(f"[INFO] CUDA: {torch.cuda.get_device_name(0)}")
    except Exception as e:
        print(f"[WARN] Failed to move model to {DEVICE}, using CPU. Reason: {e}")

    # warmup
    try:
        _ = model.predict(np.zeros((CFG.IMGSZ, CFG.IMGSZ, 3), np.uint8),
                          imgsz=CFG.IMGSZ, conf=0.01, device=DEVICE,
                          half=HALF, verbose=False)
    except Exception:
        pass

    gate_ids = auto_gate_ids_by_name(model)
    return model, gate_ids


def auto_gate_ids_by_name(model) -> set:
    return {i for i, name in model.names.items() if 'gate' in str(name).lower()}


def pick_gate_bbox(results, allow_ids):
    """从 YOLO 结果中选出面积最大的 gate bbox。"""
    boxes = results[0].boxes if results else None
    if boxes is None or len(boxes) == 0:
        return None
    best, best_area = None, 0.0
    for b in boxes:
        xyxy = b.xyxy[0].detach().cpu().numpy()
        cls = int(b.cls[0].item()) if b.cls is not None else -1
        if allow_ids is not None and cls not in allow_ids:
            continue
        x1, y1, x2, y2 = xyxy
        area = max(0.0, x2 - x1) * max(0.0, y2 - y1)
        if area > best_area:
            best_area, best = area, xyxy
    return best


def run_yolo(model, frame_rgb, gate_ids):
    """
    执行 YOLO 推理，返回 (yolo_res_dict, vis_rgb)。
    yolo_res_dict: {"ok": True, "bbox": (x1,y1,x2,y2), "center": (cx,cy), "area_frac": float}
    """
    h, w = frame_rgb.shape[:2]
    results = model.predict(frame_rgb, imgsz=CFG.IMGSZ, conf=CFG.CONF, iou=CFG.IOU,
                            max_det=CFG.MAX_DET, device=DEVICE, half=HALF, verbose=False)
    yolo_bbox = pick_gate_bbox(results, gate_ids)
    yolo_res = None
    if yolo_bbox is not None:
        x1, y1, x2, y2 = map(int, yolo_bbox)
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        area_frac = ((x2 - x1) * (y2 - y1)) / float(w * h)
        yolo_res = {"ok": True, "bbox": (x1, y1, x2, y2),
                    "center": (cx, cy), "area_frac": area_frac}

    vis = results[0].plot() if results else frame_rgb
    if vis is not frame_rgb:
        vis = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)
    return yolo_res, vis


# =========================
# RED color detection
# =========================

LOWER_RED1 = np.array([0,  80,  80], dtype=np.uint8)
UPPER_RED1 = np.array([10, 255, 255], dtype=np.uint8)
LOWER_RED2 = np.array([170, 80,  80], dtype=np.uint8)
UPPER_RED2 = np.array([179, 255, 255], dtype=np.uint8)
KERNEL = np.ones((3, 3), np.uint8)

MIN_GATE_AREA_FRAC = 0.01
AR_MIN, AR_MAX = 0.4, 2.5


def detect_red_bbox_rgb(frame_rgb):
    """
    在 RGB 图上做红色 HSV 掩膜，返回最大满足条件的轮廓 bbox。
    返回 {"ok": True, "bbox": ..., "center": ..., "area_frac": ...} 或 None。
    """
    h, w = frame_rgb.shape[:2]
    hsv = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2HSV)
    m1 = cv2.inRange(hsv, LOWER_RED1, UPPER_RED1)
    m2 = cv2.inRange(hsv, LOWER_RED2, UPPER_RED2)
    mask = cv2.bitwise_or(m1, m2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN,  KERNEL, iterations=1)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, KERNEL, iterations=2)

    cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not cnts:
        return None

    img_area = float(w * h)
    cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
    for c in cnts:
        area = cv2.contourArea(c)
        if area / max(1.0, img_area) < MIN_GATE_AREA_FRAC:
            continue
        x, y, bw, bh = cv2.boundingRect(c)
        ar = bh / max(1.0, bw)
        if not (AR_MIN <= ar <= AR_MAX):
            continue
        cx, cy = int(x + bw / 2), int(y + bh / 2)
        return {"ok": True, "bbox": (x, y, x + bw, y + bh),
                "center": (cx, cy), "area_frac": area / img_area}
    return None
