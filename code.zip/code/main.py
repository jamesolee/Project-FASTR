# -*- coding: utf-8 -*-
"""
主循环：Tello 门框穿越自主导航
- YOLO + RED 双通道门框检测
- CandidatePlanner 锚点轨迹规划
- TTC 触发穿门承诺态
- TopDownMap 俯视里程计可视化

运行前确认 bestBy11s.pt 在上层目录，或修改 config.py 中 MODEL_PATH。
"""
import os
import sys
import time
import unicodedata

import cv2
import numpy as np
from djitellopy import Tello
from djitellopy.tello import TelloException

# 把 code/ 目录加入搜索路径（直接从 code/ 内运行时不需要这行）
sys.path.insert(0, os.path.dirname(__file__))

from config import CFG
from detection import load_model, run_yolo, detect_red_bbox_rgb
from controller import (clamp, safe_send_rc,
                        Controller, StickyRC,
                        ZOffsetOnce, ForwardBurstOnce, GateCrossSM)
from planner import CandidatePlanner
from topdown_map import TopDownMap
from hud import draw_hud_rgb, rgb_to_bgr


# =========================
# 键盘轮询（Windows msvcrt + OpenCV 双路）
# =========================

def poll_key():
    try:
        import msvcrt
        if msvcrt.kbhit():
            ch = unicodedata.normalize('NFKC', msvcrt.getwch())
            if ch:
                return ch
    except Exception:
        pass
    k = cv2.waitKey(1)
    if k == -1:
        return None
    if k == 27:
        return 'ESC'
    try:
        ch = chr(k & 0xFF)
    except Exception:
        return None
    return unicodedata.normalize('NFKC', ch)


# =========================
# 视频流看门狗
# =========================

def make_restart_video(tello):
    """返回一个 restart_video 闭包，捕获 tello 与 reader/last_frame_ok 引用。"""
    state = {"reader": None, "last_frame_ok": time.time()}

    def restart_video():
        print("[WARN] video stalled — restarting stream...")
        try:
            state["reader"].stop()
        except Exception:
            pass
        try:
            tello.streamoff()
        except Exception:
            pass
        time.sleep(0.2)
        try:
            tello.streamon()
        except Exception as e:
            print(f"[WARN] streamon failed: {e}")
        time.sleep(0.4)
        state["reader"] = tello.get_frame_read()
        try:
            state["reader"].cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        state["last_frame_ok"] = time.time()

    return state, restart_video


# =========================
# apply_biases：穿门时叠加偏置
# =========================

def apply_biases(r, p, z, y, expect_pitch, zoffset, forwardburst, cross_sm):
    z += zoffset.bias()
    p = max(p, forwardburst.bias())
    if cross_sm.step():
        y = clamp(y, -CFG.CROSS_YAW_LIMIT, CFG.CROSS_YAW_LIMIT)
        p = max(p, max(CFG.TARGET_FWD, expect_pitch))
    return r, p, z, y


# =========================
# main
# =========================

def main():
    # ---- 模型 ----
    model, gate_ids = load_model()

    # ---- Tello ----
    tello = Tello()
    print("[INFO] Connecting to Tello...")
    tello.connect()
    try:
        batt = tello.get_battery()
        print(f"[INFO] Tello connected. Battery: {batt}%")
    except Exception:
        print("[INFO] Tello connected.")
    tello.streamon()

    stream_state, restart_video = make_restart_video(tello)
    stream_state["reader"] = tello.get_frame_read()
    time.sleep(0.25)

    # ---- 窗口 ----
    cv2.namedWindow("Tello (YOLO+RED+Candidates)", cv2.WINDOW_NORMAL)
    if CFG.MAP_ON:
        cv2.namedWindow("Top-Down Map", cv2.WINDOW_NORMAL)

    # ---- 组件 ----
    topo        = TopDownMap(CFG.FRAME_W, CFG.FRAME_H)
    controller  = Controller(CFG.FRAME_W, CFG.FRAME_H)
    planner     = CandidatePlanner(CFG.FRAME_W, CFG.FRAME_H)
    sticky      = StickyRC()
    zoffset     = ZOffsetOnce()
    forwardburst = ForwardBurstOnce()
    cross_sm    = GateCrossSM()

    flying      = False
    auto_mode   = True
    yaw_dir     = 1
    last_yaw_flip = time.time()
    last_rc     = (0, 0, 0, 0)
    manual_hold = (0, 0, 0, 0)
    prev_area   = 0.0
    prev_area_t = time.time()

    try:
        while True:
            reader = stream_state["reader"]
            frame_bgr = reader.frame

            if frame_bgr is None:
                if time.time() - stream_state["last_frame_ok"] > 0.8:
                    restart_video()
                    continue
                time.sleep(0.005)
                continue
            else:
                stream_state["last_frame_ok"] = time.time()

            frame_bgr = cv2.resize(frame_bgr, (CFG.FRAME_W, CFG.FRAME_H))
            frame_rgb = frame_bgr  # BGR≈RGB for Tello (already BGR from OpenCV)
            h, w = frame_rgb.shape[:2]

            # ---- 检测 ----
            red_res = detect_red_bbox_rgb(frame_rgb)
            red_ok  = red_res is not None and red_res.get("ok", False)

            yolo_res = None
            vis = frame_rgb
            if model is not None:
                yolo_res, vis = run_yolo(model, frame_rgb, gate_ids)

            # ---- 键盘 ----
            key = poll_key()
            if key == 'c': planner.toggle_overlay()
            if key == 'b': planner.toggle_backup()
            if key == 'g': topo.toggle()
            if key == 'o': topo.recenter()
            if key == 'u': topo.clear_trail()

            # 起降 / 模式
            if key == 't' and not flying:
                try:
                    b = tello.get_battery()
                    if b is not None and b < 15:
                        print("[WARN] Battery low (<15%).")
                    tello.takeoff()
                    flying = True
                    auto_mode = False
                    print("[MODE] MANUAL after takeoff (press 'm' for AUTO).")
                except TelloException as e:
                    print(f"[WARN] takeoff rejected: {e}")
                except Exception as e:
                    print(f"[WARN] takeoff error: {e}")

            elif key == 'l' and flying:
                try:
                    safe_send_rc(tello, 0, 0, 0, 0, "land-stop")
                    tello.land()
                    flying = False
                except Exception as e:
                    print(f"[WARN] land error: {e}")

            elif key == 'm':
                auto_mode = not auto_mode
                print(f"[MODE] {'AUTO' if auto_mode else 'MANUAL'}")

            elif key == 'ESC':
                print("[INFO] Quit")
                break

            # ---- 手动控制 ----
            if flying and not auto_mode:
                vel = 25
                r, p, z, y = manual_hold
                updated = False
                if   key == 'w': p = +vel; updated = True
                elif key == 's': p = -vel; updated = True
                elif key == 'a': r = -vel; updated = True
                elif key == 'd': r = +vel; updated = True
                elif key == 'r': z = +vel; updated = True
                elif key == 'f': z = -vel; updated = True
                elif key == 'q': y = -vel; updated = True
                elif key == 'e': y = +vel; updated = True
                elif key == 'x': r = p = z = y = 0; updated = True
                if updated:
                    manual_hold = (r, p, z, y)
                    last_rc = (r, p, z, y)
                    safe_send_rc(tello, r, p, z, y, tag="MANUAL")

            # ---- 选择控制目标 ----
            area_for_trigger = 0.0
            center_for_ctrl  = None
            bbox_for_bonus   = None
            if red_ok:
                center_for_ctrl  = red_res["center"]
                area_for_trigger = red_res["area_frac"]
                bbox_for_bonus   = red_res["bbox"]
            elif yolo_res and yolo_res.get("ok", False):
                center_for_ctrl  = yolo_res["center"]
                area_for_trigger = yolo_res["area_frac"]
                bbox_for_bonus   = yolo_res["bbox"]

            near_gate = area_for_trigger >= CFG.NEAR_GATE_AREA_FRAC

            # TTC 计算
            now_t = time.time()
            dt_area = max(1e-3, now_t - prev_area_t)
            d_area  = (area_for_trigger - prev_area) / dt_area
            ttc = None
            if d_area > CFG.TTC_MIN_DAREA:
                ttc = area_for_trigger / d_area
            prev_area   = area_for_trigger
            prev_area_t = now_t

            # 候选规划
            top1 = top2 = None
            ranked = None
            if center_for_ctrl is not None:
                top1, top2, ranked = planner.select(center_for_ctrl, bbox_for_bonus)
                planner.draw(vis, ranked, top1, top2)

            # ---- 自动控制 ----
            if flying and auto_mode:
                expect_pitch = CFG.TARGET_FWD + (CFG.FWD_NEAR_BOOST if near_gate else 0)

                # 穿门触发
                if (near_gate and d_area > 0) or (ttc is not None and ttc < CFG.TTC_TRIGGER_SEC):
                    if not cross_sm.active:
                        zoffset.trigger()
                        forwardburst.trigger(expect_pitch)
                        cross_sm.start(CFG.CROSS_HOLD_SEC)

                if center_for_ctrl is not None:
                    # 选锚点目标
                    if planner.use_backup and top2 is not None:
                        target_px = (int(top2[0]), int(top2[1]))
                    elif top1 is not None:
                        target_px = (int(top1[0]), int(top1[1]))
                    else:
                        target_px = center_for_ctrl

                    r, p, z, y, pos = controller.compute_to_point(
                        target_px, area_for_trigger, near_gate, has_gate=True)
                    r, p, z, y = apply_biases(r, p, z, y, expect_pitch,
                                              zoffset, forwardburst, cross_sm)
                    last_rc = (int(r), int(p), int(z), int(y))
                    planner.commit_prev(target_px)
                    sticky.set((int(r), int(p), int(z), int(y), pos))
                    tag = "AUTO-CAND-ALT" if planner.use_backup else "AUTO-CAND"
                    safe_send_rc(tello, *last_rc, tag=tag)

                else:
                    # 目标丢失：sticky 衰减 or 搜索
                    rc = sticky.lost_tick_and_get()
                    if rc is not None:
                        r, p, z, y, pos = rc
                        r, p, z, y = apply_biases(r, p, z, y, p,
                                                  zoffset, forwardburst, cross_sm)
                        last_rc = (int(r), int(p), int(z), int(y))
                        safe_send_rc(tello, *last_rc, tag="AUTO-STICKY")
                    else:
                        now = time.time()
                        if now - last_yaw_flip > 2.5:
                            yaw_dir = -1 if np.random.rand() > 0.5 else 1
                            last_yaw_flip = now
                        r, p, z, y = 0, CFG.SEARCH_FWD, 0, yaw_dir * CFG.SEARCH_YAW_DPS
                        r, p, z, y = apply_biases(r, p, z, y, p,
                                                  zoffset, forwardburst, cross_sm)
                        last_rc = (int(r), int(p), int(z), int(y))
                        safe_send_rc(tello, *last_rc, tag="AUTO-SEARCH")

            # ---- HUD ----
            ex, ey, af = controller.ex_prev, controller.ey_prev, controller.af_ema.v
            cand_text = ""
            if top1 is not None:
                cand_text += f"Cands: TOP1 J={top1[2]:.3f}"
            if top2 is not None:
                cand_text += f" | TOP2 J={top2[2]:.3f}"
            if planner.use_backup:
                cand_text += " | USE=ALT#2"
            if ttc is not None:
                cand_text += f" | TTC={ttc:.2f}s"

            draw_hud_rgb(vis, red_res if red_ok else None,
                         yolo_res, last_rc, (ex, ey, af),
                         cross_sm.active, area_for_trigger, cand_text)

            # ---- 顶视图 ----
            now_t_map = time.time()
            dt_map = max(1e-3, now_t_map - topo.last_t)
            topo.last_t = now_t_map
            topo.step_odometry(last_rc, dt_map)

            # NOTE: PnP 距离估计已禁用（门框大小不一，GATE_W_M 固定值不准）
            # if yolo_res and yolo_res.get("ok", False):
            #     topo.observe_gate_from_bbox(yolo_res["bbox"], yolo_res["center"])
            # if red_ok:
            #     topo.observe_gate_from_bbox(red_res["bbox"], red_res["center"])
            topo.observe_candidates(top1, top2)

            if topo.show:
                cv2.imshow("Top-Down Map", topo.render())

            cv2.imshow("Tello (YOLO+RED+Candidates)", rgb_to_bgr(vis))

    finally:
        try: safe_send_rc(tello, 0, 0, 0, 0, "finally")
        except Exception: pass
        try: tello.streamoff()
        except Exception: pass
        try: tello.end()
        except Exception: pass
        try: cv2.destroyAllWindows()
        except Exception: pass


if __name__ == "__main__":
    main()
