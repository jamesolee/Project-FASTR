# -*- coding: utf-8 -*-
"""
2D 顶视图（TopDownMap）：
- RC 命令积分里程计 (x, y, psi)
- bbox 宽度 + 针孔模型估距 -> gate 世界坐标投影
- 候选锚点方向射线叠加
"""
import math
import time
import cv2
import numpy as np

from config import CFG


class TopDownMap:
    def __init__(self, frame_w: int, frame_h: int):
        self.sz = CFG.MAP_SIZE
        self.ppm = CFG.MAP_PX_PER_M
        self.show = CFG.MAP_ON

        self.x_m = 0.0
        self.y_m = 0.0
        self.psi_deg = 0.0
        self.last_t = time.time()

        self.frame_w = frame_w
        self.frame_h = frame_h
        self.fx_px = 0.5 * frame_w / math.tan(math.radians(CFG.CAM_FOV_H_DEG) * 0.5)

        self.trail = []
        self.gates_world = []
        self.gates_keep = 12

        self.cx = self.sz // 2
        self.cy = self.sz // 2

        self.cand_bearings = []
        self.cand_len_m = 2.5

    # ---------- 控制 ----------

    def toggle(self):
        self.show = not self.show
        print(f"[MAP] {'ON' if self.show else 'OFF'}")

    def recenter(self):
        self.cx = self.sz // 2
        self.cy = self.sz // 2
        print("[MAP] recentered")

    def clear_trail(self):
        self.trail.clear()
        print("[MAP] trail cleared")

    # ---------- 里程计 ----------

    def step_odometry(self, rc_tuple, dt):
        r, p, z, y = rc_tuple
        v_ms = float(p) * 0.01          # cm/s -> m/s
        self.psi_deg += float(y) * dt
        psi = math.radians(self.psi_deg)
        self.x_m += v_ms * math.cos(psi) * dt
        self.y_m += v_ms * math.sin(psi) * dt

        self.trail.append((self.x_m, self.y_m))
        if len(self.trail) > CFG.TRAIL_MAX_N:
            self.trail = self.trail[-CFG.TRAIL_MAX_N:]

    # ---------- 视觉观测 ----------

    def observe_gate_from_bbox(self, bbox, center_xy):
        # NOTE: 已注释 — 针孔模型距离估计假设所有门框宽度固定 (GATE_W_M)，
        # 但实际场景中门框大小不一，估距误差大，暂时禁用。
        # 若后续用 RGB-D 或标定后重新启用，取消下方注释即可。
        #
        # if bbox is None or center_xy is None:
        #     return
        # x1, y1, x2, y2 = bbox
        # u0 = self.frame_w / 2.0
        # bw = max(1.0, x2 - x1)
        # u, _ = center_xy
        # Z_m = (self.fx_px * CFG.GATE_W_M) / bw
        # yaw_off = math.atan((u - u0) / self.fx_px)
        # bearing = math.radians(self.psi_deg) + yaw_off
        # gx = self.x_m + Z_m * math.cos(bearing)
        # gy = self.y_m + Z_m * math.sin(bearing)
        # self.gates_world.append((gx, gy, time.time()))
        # if len(self.gates_world) > self.gates_keep:
        #     self.gates_world = self.gates_world[-self.gates_keep:]
        pass

    def observe_candidates(self, top1, top2):
        self.cand_bearings.clear()
        for top, col in [(top1, (0, 255, 0)), (top2, (0, 255, 255))]:
            if top is None:
                continue
            u, v, J = top
            u0 = self.frame_w / 2.0
            yaw_off = math.atan((u - u0) / self.fx_px)
            bearing = math.radians(self.psi_deg) + yaw_off
            self.cand_bearings.append((bearing, col))

    # ---------- 渲染 ----------

    def _w2p(self, x_m, y_m):
        px = int(self.cx + x_m * self.ppm)
        py = int(self.cy - y_m * self.ppm)
        return (px, py)

    def _draw_grid(self, img):
        step_px = self.ppm
        for k in range(0, self.sz, step_px):
            cv2.line(img, (k, 0),       (k, self.sz),   (40, 40, 40), 1)
            cv2.line(img, (0, k),       (self.sz, k),   (40, 40, 40), 1)
        cv2.line(img, (self.cx, 0),     (self.cx, self.sz), (80, 80, 80), 1)
        cv2.line(img, (0, self.cy),     (self.sz, self.cy), (80, 80, 80), 1)

    def render(self):
        img = np.zeros((self.sz, self.sz, 3), np.uint8)
        self._draw_grid(img)

        if len(self.trail) >= 2:
            for i in range(1, len(self.trail)):
                p0 = self._w2p(*self.trail[i - 1])
                p1 = self._w2p(*self.trail[i])
                cv2.line(img, p0, p1, (90, 90, 200), 2)

        for (gx, gy, t) in self.gates_world:
            gp = self._w2p(gx, gy)
            cv2.circle(img, gp, 6,  (255, 255, 255), -1)
            cv2.circle(img, gp, 12, (100, 100, 100),  1)

        origin = self._w2p(self.x_m, self.y_m)
        for bearing, col in self.cand_bearings:
            end = (self.x_m + self.cand_len_m * math.cos(bearing),
                   self.y_m + self.cand_len_m * math.sin(bearing))
            endp = self._w2p(*end)
            cv2.arrowedLine(img, origin, endp, col, 3, tipLength=0.12)

        psi = math.radians(self.psi_deg)
        nose  = (self.x_m + 0.25 * math.cos(psi),       self.y_m + 0.25 * math.sin(psi))
        left  = (self.x_m + 0.12 * math.cos(psi + 2.6), self.y_m + 0.12 * math.sin(psi + 2.6))
        right = (self.x_m + 0.12 * math.cos(psi - 2.6), self.y_m + 0.12 * math.sin(psi - 2.6))
        pts = np.array([self._w2p(*nose), self._w2p(*left), self._w2p(*right)], np.int32)
        cv2.fillConvexPoly(img, pts, (0, 180, 255))
        cv2.polylines(img, [pts], True, (0, 0, 0), 2)

        cv2.putText(img,
                    f"(x,y)=({self.x_m:+.1f}m,{self.y_m:+.1f}m) psi={self.psi_deg:+.1f}deg",
                    (10, 22), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (200, 200, 200), 2)
        cv2.putText(img, "Keys: g map on/off | o recenter | u clear trail",
                    (10, self.sz - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180, 180, 180), 1)
        return img
