# -*- coding: utf-8 -*-
"""
飞控相关模块：
- clamp / safe_send_rc
- EMA 滤波器
- norm_errors
- StickyRC
- ZOffsetOnce / ForwardBurstOnce
- GateCrossSM
- Controller
"""
import time
from djitellopy import Tello

from config import CFG


# =========================
# RC 工具
# =========================

_last_rc_sent = (0, 0, 0, 0)
_last_rc_time = 0.0


def clamp(x, lo, hi):
    return max(lo, min(hi, int(x)))


def safe_send_rc(tello: Tello, r: int, p: int, z: int, y: int, tag: str = ""):
    """限速率 + 去重发送。"""
    global _last_rc_sent, _last_rc_time
    r = clamp(r, -CFG.MAX_CMD, CFG.MAX_CMD)
    p = clamp(p, -CFG.MAX_CMD, CFG.MAX_CMD)
    z = clamp(z, -CFG.MAX_CMD, CFG.MAX_CMD)
    y = clamp(y, -CFG.MAX_CMD, CFG.MAX_CMD)

    now = time.time()
    min_interval = 1.0 / CFG.RC_RATE_HZ
    if (now - _last_rc_time) < min_interval and (r, p, z, y) == _last_rc_sent:
        return
    try:
        tello.send_rc_control(r, p, z, y)
        _last_rc_sent = (r, p, z, y)
        _last_rc_time = now
        print(f"[RC]{'[' + tag + ']' if tag else ''} r={r:+d} p={p:+d} z={z:+d} y={y:+d}")
    except Exception as e:
        print("[WARN] rc_control error:", e)


# =========================
# EMA 滤波
# =========================

class EMA:
    def __init__(self, alpha: float, init: float = 0.0):
        self.a = float(alpha)
        self.v = float(init)
        self.initd = False

    def update(self, x: float):
        if not self.initd:
            self.v = float(x)
            self.initd = True
        else:
            self.v = self.a * float(x) + (1.0 - self.a) * self.v
        return self.v


def norm_errors(center_xy, frame_w, frame_h):
    cx_img, cy_img = frame_w // 2, frame_h // 2
    cx, cy = center_xy
    ex = (cx - cx_img) / (frame_w * 0.5)
    ey = (cy - cy_img) / (frame_h * 0.5)
    return float(ex), float(ey)


# =========================
# StickyRC：目标丢失后衰减保持
# =========================

class StickyRC:
    def __init__(self):
        self.rc = (0, 0, 0, 0, (0.0, 0.0, 0.0))
        self.frames = 0
        self.valid = False

    def set(self, rc_tuple):
        self.rc = rc_tuple
        self.frames = 0
        self.valid = True

    def lost_tick_and_get(self):
        if not self.valid:
            return None
        self.frames += 1
        if self.frames > CFG.STICKY_MAX_FRAMES:
            self.valid = False
            return None
        r, p, t, y, pos = self.rc
        dec = CFG.STICKY_DECAY ** self.frames
        r = clamp(int(r * dec), -CFG.MAX_CMD, CFG.MAX_CMD)
        p = clamp(int(p * dec), -CFG.MAX_CMD, CFG.MAX_CMD)
        t = clamp(int(t * dec), -CFG.MAX_CMD, CFG.MAX_CMD)
        y = clamp(int(y * dec), -CFG.MAX_CMD, CFG.MAX_CMD)
        return (r, p, t, y, pos)


# =========================
# One-shot 下压偏置
# =========================

class ZOffsetOnce:
    def __init__(self):
        self.active = False
        self.end_time = 0.0

    def trigger(self):
        dur = CFG.Z_OFFSET_CM / float(max(1, CFG.Z_OFFSET_SPEED))
        self.active = True
        self.end_time = time.time() + dur
        print(f"[Z-OFFSET] start: -{CFG.Z_OFFSET_CM}cm at {CFG.Z_OFFSET_SPEED}cm/s for {dur:.2f}s")

    def bias(self):
        if not self.active:
            return 0
        if time.time() >= self.end_time:
            self.active = False
            print("[Z-OFFSET] done")
            return 0
        return -int(CFG.Z_OFFSET_SPEED)


# =========================
# One-shot 前冲
# =========================

class ForwardBurstOnce:
    def __init__(self):
        self.active = False
        self.end_time = 0.0
        self.speed = 0

    def trigger(self, current_pitch_cm_s: int):
        v = max(abs(int(current_pitch_cm_s)), CFG.FORWARD_BURST_MIN_SPEED, 10)
        dur = CFG.FORWARD_BURST_CM / float(v)
        self.speed = v
        self.end_time = time.time() + dur
        self.active = True
        print(f"[FWD-BURST] start: +{CFG.FORWARD_BURST_CM}cm at {v}cm/s for {dur:.2f}s")

    def bias(self):
        if not self.active:
            return 0
        if time.time() >= self.end_time:
            self.active = False
            print("[FWD-BURST] done")
            return 0
        return int(self.speed)


# =========================
# 穿门状态机
# =========================

class GateCrossSM:
    """进入后在短时内"坚持穿门"：限小 yaw + 强前进 + 可叠加下压。"""
    def __init__(self):
        self.active = False
        self.until = 0.0

    def start(self, hold_sec: float):
        self.active = True
        self.until = time.time() + float(hold_sec)
        print(f"[CROSS] commit for {hold_sec:.2f}s")

    def step(self):
        if self.active and time.time() >= self.until:
            self.active = False
            print("[CROSS] done")
        return self.active


# =========================
# Controller：图像误差 -> RC 指令
# =========================

class Controller:
    def __init__(self, w: int, h: int):
        self.w = w
        self.h = h
        self.ex_ema = EMA(CFG.EMA_ALPHA_ERR, 0.0)
        self.ey_ema = EMA(CFG.EMA_ALPHA_ERR, 0.0)
        self.af_ema = EMA(CFG.EMA_ALPHA_AREA, 0.0)
        self.ex_prev = 0.0
        self.ey_prev = 0.0
        self.t_prev = time.time()

    def _core(self, ex, ey, area_frac, near_gate: bool, has_gate: bool):
        if not has_gate:
            return 0, CFG.SEARCH_FWD, 0, CFG.SEARCH_YAW_DPS, (0.0, 0.0, 0.0)

        # deadband + EMA
        if abs(ex) < CFG.ERR_DEAD_BAND: ex = 0.0
        if abs(ey) < CFG.ERR_DEAD_BAND: ey = 0.0
        ex_f = self.ex_ema.update(ex)
        ey_f = self.ey_ema.update(ey)
        af_f = self.af_ema.update(max(0.0, float(area_frac)))

        now = time.time()
        dt = max(1e-3, now - self.t_prev)
        self.ex_prev, self.ey_prev, self.t_prev = ex_f, ey_f, now

        yaw  = clamp(int(CFG.K_YAW * ex_f),  -CFG.MAX_CMD, CFG.MAX_CMD)
        kroll = CFG.K_ROLL_NEAR if near_gate else CFG.K_ROLL_FAR
        roll = clamp(int(kroll * ex_f),       -CFG.MAX_CMD, CFG.MAX_CMD)
        thr  = clamp(int(-CFG.K_THR * ey_f),  -CFG.MAX_CMD, CFG.MAX_CMD)
        pitch_ff = CFG.TARGET_FWD + (CFG.FWD_NEAR_BOOST if near_gate else 0)
        pitch = clamp(int(pitch_ff),           -CFG.MAX_CMD, CFG.MAX_CMD)
        return roll, pitch, thr, yaw, (ex_f, ey_f, af_f)

    def compute(self, center_xy, area_frac, near_gate: bool, has_gate: bool):
        """以门中心为控制目标。"""
        ex, ey = norm_errors(center_xy, self.w, self.h)
        return self._core(ex, ey, area_frac, near_gate, has_gate)

    def compute_to_point(self, target_xy, area_frac, near_gate: bool, has_gate: bool):
        """以候选锚点像素为控制目标。"""
        ex, ey = norm_errors(target_xy, self.w, self.h)
        return self._core(ex, ey, area_frac, near_gate, has_gate)
