# -*- coding: utf-8 -*-
"""
集中所有可调参数 + 设备初始化
"""
import torch
from dataclasses import dataclass


@dataclass
class Config:
    # Model/runtime
    MODEL_PATH: str = "bestBy11s.pt"
    IMGSZ: int = 640
    CONF: float = 0.64
    IOU: float = 0.45
    MAX_DET: int = 10

    # Frame & normalization
    FRAME_W: int = 960
    FRAME_H: int = 720

    # Error processing
    ERR_DEAD_BAND: float = 0.04
    EMA_ALPHA_ERR: float = 0.35
    EMA_ALPHA_AREA: float = 0.30

    # Control gains (相机坐标 -> RC)
    K_YAW: float  = 55.0
    K_ROLL_NEAR: float = 28.0
    K_ROLL_FAR: float  = 14.0
    K_THR: float   = 52.0
    TARGET_FWD: int = 20
    FWD_NEAR_BOOST: int = 28
    NEAR_GATE_AREA_FRAC: float = 0.15

    # Candidate planner (anchors)
    CAND_M_THETA: int = 5        # 水平网格列数（Mθ）
    CAND_M_PHI: int   = 3        # 垂直网格行数（Mφ）
    CAND_WG: float    = 1.00     # 目标对齐代价权重 Jg
    CAND_WEDGE: float = 0.30     # 贴边惩罚权重（避免靠近画面边界丢失）
    CAND_WSM: float   = 0.20     # 平滑代价（与上次选中的锚点差异）
    CAND_WBOX: float  = -0.25    # 在门框 bbox 内的奖励（负号=减小代价）
    CAND_NMS_PX: int  = 120      # NMS 的最小像素间距（#2 需与 #1 保持一定差异）
    CAND_DRAW: bool   = True     # 是否叠加显示候选
    CAND_MAX_DRAW: int = 64      # 控制绘制数量（节省开销）

    # TTC 触发
    TTC_TRIGGER_SEC: float = 0.70  # 当 TTC < 此值触发穿门承诺态
    TTC_MIN_DAREA: float = 1e-5    # 计算 TTC 时的最小面积增量，避免除零

    # Search 策略
    SEARCH_YAW_DPS: int = 16
    SEARCH_FWD: int = 6

    # RC & safety
    MAX_CMD: int = 100
    RC_RATE_HZ: float = 20.0
    STICKY_MAX_FRAMES: int = 20
    STICKY_DECAY: float = 0.90

    # Gate-cross（穿门）策略
    Z_OFFSET_CM: int = 30
    Z_OFFSET_SPEED: int = 28
    FORWARD_BURST_CM: int = 75
    FORWARD_BURST_MIN_SPEED: int = 28
    CROSS_HOLD_SEC: float = 1.0
    CROSS_YAW_LIMIT: int = 15

    # Top-down Map (Bird's-eye)
    MAP_ON: bool = True
    MAP_SIZE: int = 700
    MAP_PX_PER_M: int = 80
    CAM_FOV_H_DEG: float = 82.6   # Tello 水平视场角（近似）
    GATE_W_M: float = 0.8         # gate 实际宽度（米）
    TRAIL_MAX_N: int = 2000


CFG = Config()

DEVICE = "cuda:0" if torch.cuda.is_available() else "cpu"
HALF = (torch.cuda.is_available() and DEVICE.startswith("cuda"))

if torch.cuda.is_available():
    torch.backends.cudnn.benchmark = True
    torch.backends.cuda.matmul.allow_tf32 = True
